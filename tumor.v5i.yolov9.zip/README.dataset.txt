# tumor > 2024-01-09 9:28pm
https://universe.roboflow.com/ysa-9gjhm/tumor-sxfyw

Provided by a Roboflow user
License: CC BY 4.0

